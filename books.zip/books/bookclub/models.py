from django.contrib.auth.models import User
from django.db import models


class Book(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=200)
    description = models.TextField()
    is_available = models.NullBooleanField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    publish_date = models.DateField(null=True, blank=True)
    checkouts = models.ManyToManyField(User, through='Checkout')

    def __str__(self):
        """A string representation of the model."""
        return self.title


class Checkout(models.Model):
    book = models.ForeignKey(Book, on_delete=models.PROTECT)
    user = models.ForeignKey(User, on_delete=models.PROTECT)
    issue_date = models.DateTimeField(auto_now_add=True)
    due_date = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        """A string representation of the model."""
        return self.book.title + ' - currently issued to -> ' + self.user.username