from django.apps import AppConfig


class BookclubConfig(AppConfig):
    name = 'bookclub'
