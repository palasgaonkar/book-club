from django.contrib import admin
from django.urls import reverse
from django.utils.html import format_html

from .models import Book, User, Checkout


class user_inline(admin.TabularInline):
    model = Book.checkouts.through
    extra = 1


class BookAdmin(admin.ModelAdmin):
    model = Book
    # a list of displayed columns name.
    list_display = ['title', 'description', 'is_available']
    search_fields = ['title']
    list_filter = ('is_available', )
    ordering = ('id', )
    inlines = (user_inline, )


class CheckoutAdmin(admin.ModelAdmin):
    model = Checkout
    # a list of displayed columns name.
    list_display = ['id', 'link_to_book', 'link_to_user', 'issue_date', 'due_date']
    search_fields = ['book__title', 'user__username']
    ordering = ('-id', )

    def link_to_user(self, obj):
        link = reverse("admin:auth_user_change", args=[obj.user.id])
        return format_html('<a href="{}">{}</a>', link, obj.user.username)

    def link_to_book(self, obj):
        link = reverse("admin:bookclub_book_change", args=[obj.book.id])
        return format_html('<a href="{}">{}</a>', link, obj.book.title)


admin.site.register(Book, BookAdmin)
admin.site.register(Checkout, CheckoutAdmin)